https://modrinth.com/modpack/versatile
